package com.sdpd_d_batch3.wase15.my_tictactoe;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declare Elements
    Button b1, b2, b3, b4, b5, b6, b7, b8, b9, ng; //ALL BUTTONS
    ImageView strike; // FOR SHOW WIN LINES
    ImageButton ib;  // FOR DISPLAYING CONTEXT MENU
    TextView tv1;  // FOR SHOWING HEADER
    int c[][]; //Multi Dim Array to hold cell data
    int player; //For player = 1, player = 2
    SharedPreferences sp; // To Store Data
    SharedPreferences.Editor se; // To Store Data
    int p1_score, p2_score, draw_score; // To Store Data

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Initilize score values to Zero
        p1_score = p2_score = draw_score = 0;
        //Set Shared Preferences , with Key as "my_scores"
        sp = getApplicationContext().getSharedPreferences("my_scores", Context.MODE_PRIVATE);
        se = sp.edit();
        //Get Shared Preferences using key as "my_scores"
        sp = getSharedPreferences("my_scores", Context.MODE_PRIVATE);

        //Initilize Imageview that is used for displaying line after user wins
        strike = (ImageView) findViewById(R.id.pattern);


        // Initilize Buttons
        b1 = (Button) findViewById(R.id.button1);
        b2 = (Button) findViewById(R.id.button2);
        b3 = (Button) findViewById(R.id.button3);
        b4 = (Button) findViewById(R.id.button4);
        b5 = (Button) findViewById(R.id.button5);
        b6 = (Button) findViewById(R.id.button6);
        b7 = (Button) findViewById(R.id.button7);
        b8 = (Button) findViewById(R.id.button8);
        b9 = (Button) findViewById(R.id.button9);
        ng = (Button) findViewById(R.id.reset);
        /*
        // Initilize TextView*/
        tv1 = (TextView) findViewById(R.id.textView1);
        ng.setEnabled(false);

        //Set Font to Main Header "TIC TAC TOE"
        Typeface typeFace_t = Typeface.createFromAsset(getAssets(), "planet_benson.ttf");
        tv1.setTypeface(typeFace_t);

        //Set Font to all nine buttons
        Typeface typeFace_v = Typeface.createFromAsset(getAssets(), "bring_the_noize.ttf");//
        b1.setTypeface(typeFace_v);
        b2.setTypeface(typeFace_v);
        b3.setTypeface(typeFace_v);
        b4.setTypeface(typeFace_v);
        b5.setTypeface(typeFace_v);
        b6.setTypeface(typeFace_v);
        b7.setTypeface(typeFace_v);
        b8.setTypeface(typeFace_v);
        b9.setTypeface(typeFace_v);

        //initilize all array elements with zero
        c = new int[3][3];
        initArrayZero();

        //ib is a image button on TOP RIGHT CORNER
        //Used to display CONTEXT MENU on CLICK
        ib = (ImageButton) findViewById(R.id.imageButton);
        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerForContextMenu(ib);
                openContextMenu(ib);

            }
        });
        ib.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Toast.makeText(getApplicationContext(), "More Features Coming Soon..", Toast.LENGTH_LONG).show();
                return true;
            }
        });

        //BUTTON 1 CLICK
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (b1.isEnabled()) { //IF BUTTON IS NOT DISABLED
                    if (player == 1) { //IF ITS PLAYER 1 TURN
                        b1.setText("O"); //SET BUTTON TEXT AS 'O'
                        b1.setBackgroundColor(Color.CYAN); //SET PLAYER 1 COLOR TO CYAN
                        buttonclick("b1", 1); //CALL BUTTONCLICK() METHOD WITH ITS PARAMETERS
                        player = 2; //NEXT TURN PLAYER 2
                    } else {   //ELSE ITS PLAYER 2 TURN
                        b1.setText("X");
                        b1.setBackgroundColor(Color.MAGENTA);
                        buttonclick("b1", 2);
                        player = 1; //NEXT TURN PLAYER 1
                    }

                }
            }
        });

        //BUTTON 2 CLICK
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (b2.isEnabled()) {
                    if (player == 1) {
                        b2.setText("O");
                        b2.setBackgroundColor(Color.CYAN);
                        buttonclick("b2", 1);
                        player = 2;
                    } else {
                        b2.setText("X");
                        b2.setBackgroundColor(Color.MAGENTA);
                        buttonclick("b2", 2);
                        player = 1;
                    }
                }
            }
        });

        //BUTTON 3 CLICK
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (b3.isEnabled()) {
                    if (player == 1) {
                        b3.setText("O");
                        b3.setBackgroundColor(Color.CYAN);
                        buttonclick("b3", 1);
                        player = 2;
                    } else {
                        b3.setText("X");
                        b3.setBackgroundColor(Color.MAGENTA);
                        buttonclick("b3", 2);
                        player = 1;
                    }
                }
            }
        });

        //BUTTON 4 CLICK
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (b4.isEnabled()) {
                    if (player == 1) {
                        b4.setText("O");
                        b4.setBackgroundColor(Color.CYAN);
                        buttonclick("b4", 1);
                        player = 2;
                    } else {
                        b4.setText("X");
                        b4.setBackgroundColor(Color.MAGENTA);
                        buttonclick("b4", 2);
                        player = 1;
                    }
                }
            }
        });

        //BUTTON 5 CLICK
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (b5.isEnabled()) {
                    if (player == 1) {
                        b5.setText("O");
                        b5.setBackgroundColor(Color.CYAN);
                        buttonclick("b5", 1);
                        player = 2;
                    } else {
                        b5.setText("X");
                        b5.setBackgroundColor(Color.MAGENTA);
                        buttonclick("b5", 2);
                        player = 1;
                    }
                }
            }
        });

        //BUTTON 6 CLICK
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (b6.isEnabled()) {
                    if (player == 1) {
                        b6.setText("O");
                        b6.setBackgroundColor(Color.CYAN);
                        buttonclick("b6", 1);
                        player = 2;
                    } else {
                        b6.setText("X");
                        b6.setBackgroundColor(Color.MAGENTA);
                        buttonclick("b6", 2);
                        player = 1;
                    }
                }
            }
        });

        //BUTTON 7 CLICK
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (b7.isEnabled()) {
                    if (player == 1) {
                        b7.setText("O");
                        b7.setBackgroundColor(Color.CYAN);
                        buttonclick("b7", 1);
                        player = 2;
                    } else {
                        b7.setText("X");
                        b7.setBackgroundColor(Color.MAGENTA);
                        buttonclick("b7", 2);
                        player = 1;
                    }
                }
            }
        });

        //BUTTON 8 CLICK
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (b8.isEnabled()) {
                    if (player == 1) {
                        b8.setText("O");
                        b8.setBackgroundColor(Color.CYAN);
                        buttonclick("b8", 1);
                        player = 2;
                    } else {
                        b8.setText("X");
                        b8.setBackgroundColor(Color.MAGENTA);
                        buttonclick("b8", 2);
                        player = 1;
                    }
                }
            }
        });

        //BUTTON 9 CLICK
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (b9.isEnabled()) {
                    if (player == 1) {
                        b9.setText("O");
                        b9.setBackgroundColor(Color.CYAN);
                        buttonclick("b9", 1);
                        player = 2;
                    } else {
                        b9.setText("X");
                        b9.setBackgroundColor(Color.MAGENTA);
                        buttonclick("b9", 2);
                        player = 1;
                    }
                }
            }
        });

        //"NEW GAME" BUTTON CLICK
        //Enable all buttons and call INITARRAYZERO Function
        ng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enableallbuttons();
                initArrayZero();
            }
        });
    }

    //used to Resets cells back to Zero, And buttons to inital setting
    private void initArrayZero() {
        player = 1;
        strike.setVisibility(View.INVISIBLE);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                c[i][j] = 0;
            }
        }
        b1.setText("");
        b1.setBackgroundColor(Color.GRAY);
        b2.setText("");
        b2.setBackgroundColor(Color.GRAY);
        b3.setText("");
        b3.setBackgroundColor(Color.GRAY);
        b4.setText("");
        b4.setBackgroundColor(Color.GRAY);
        b5.setText("");
        b5.setBackgroundColor(Color.GRAY);
        b6.setText("");
        b6.setBackgroundColor(Color.GRAY);
        b7.setText("");
        b7.setBackgroundColor(Color.GRAY);
        b8.setText("");
        b8.setBackgroundColor(Color.GRAY);
        b9.setText("");
        b9.setBackgroundColor(Color.GRAY);
    }

    //used to save data into Array and disable that button
    //Parameter : but = Button Number, play = Player(1 or 2)
    private void buttonclick(String but, int play) {
        switch (but) {
            case "b1":
                b1.setEnabled(false);
                c[0][0] = play;
                check();
                break;
            case "b2":
                b2.setEnabled(false);
                c[0][1] = play;
                check();
                break;
            case "b3":
                b3.setEnabled(false);
                c[0][2] = play;
                check();
                break;
            case "b4":
                b4.setEnabled(false);
                c[1][0] = play;
                check();
                break;
            case "b5":
                b5.setEnabled(false);
                c[1][1] = play;
                check();
                break;
            case "b6":
                b6.setEnabled(false);
                c[1][2] = play;
                check();
                break;
            case "b7":
                b7.setEnabled(false);
                c[2][0] = play;
                check();
                break;
            case "b8":
                b8.setEnabled(false);
                c[2][1] = play;
                check();
                break;
            case "b9":
                b9.setEnabled(false);
                c[2][2] = play;
                check();
                break;

        }
    }

    //used to enable all buttons
    private void enableallbuttons() {
        b1.setEnabled(true);
        b2.setEnabled(true);
        b3.setEnabled(true);
        b4.setEnabled(true);
        b5.setEnabled(true);
        b6.setEnabled(true);
        b7.setEnabled(true);
        b8.setEnabled(true);
        b9.setEnabled(true);
    }

    //used to disable all buttons
    private void disableallbuttons() {
        b1.setEnabled(false);
        b2.setEnabled(false);
        b3.setEnabled(false);
        b4.setEnabled(false);
        b5.setEnabled(false);
        b6.setEnabled(false);
        b7.setEnabled(false);
        b8.setEnabled(false);
        b9.setEnabled(false);
    }

    //Used to check the board for win(Player 1 and Player 2) and draw after every button click by user
    private void check() {

        if (/* L2R */(c[0][0] == 1 && c[0][1] == 1 && c[0][2] == 1) ||
                (c[1][0] == 1 && c[1][1] == 1 && c[1][2] == 1) ||
                (c[2][0] == 1 && c[2][1] == 1 && c[2][2] == 1) ||
                /* T2B */
                (c[0][0] == 1 && c[1][0] == 1 && c[2][0] == 1) ||
                (c[0][1] == 1 && c[1][1] == 1 && c[2][1] == 1) ||
                (c[0][2] == 1 && c[1][2] == 1 && c[2][2] == 1) ||
                /* DIAG */
                (c[0][0] == 1 && c[1][1] == 1 && c[2][2] == 1) ||
                (c[0][2] == 1 && c[1][1] == 1 && c[2][0] == 1)) {
            ng.setEnabled(true);
            disableallbuttons();
            p1_score = p1_score + 1;
            custom_toast("Player 1");
            savePoints("p1", p1_score);
            draw();
        } else if (/* L2R */(c[0][0] == 2 && c[0][1] == 2 && c[0][2] == 2) ||
                (c[1][0] == 2 && c[1][1] == 2 && c[1][2] == 2) ||
                (c[2][0] == 2 && c[2][1] == 2 && c[2][2] == 2) ||
                /* T2B */
                (c[0][0] == 2 && c[1][0] == 2 && c[2][0] == 2) ||
                (c[0][1] == 2 && c[1][1] == 2 && c[2][1] == 2) ||
                (c[0][2] == 2 && c[1][2] == 2 && c[2][2] == 2) ||
                /* DIAG */
                (c[0][0] == 2 && c[1][1] == 2 && c[2][2] == 2) ||
                (c[0][2] == 2 && c[1][1] == 2 && c[2][0] == 2)) {
            ng.setEnabled(true);
            disableallbuttons();
            p2_score = p2_score + 1;
            custom_toast("Player 2");
            savePoints("p2", p2_score);
            draw();
        } else if ((c[0][0] != 0 && c[0][1] != 0 && c[0][2] != 0 && c[1][0] != 0 && c[1][1] != 0 && c[1][2] != 0 && c[2][0] != 0 && c[2][1] != 0 && c[2][2] != 0)) {
            ng.setEnabled(true);
            disableallbuttons();
            custom_toast("draw");
            draw_score = draw_score + 1;
            savePoints("dr", draw_score);
        }
    }

    //used to put strike when user wins
    private void draw() {
        strike.setVisibility(View.VISIBLE);
        if (/* L2R */c[0][0] == 1 && c[0][1] == 1 && c[0][2] == 1 || c[0][0] == 2 && c[0][1] == 2 && c[0][2] == 2) {
            strike.setImageResource(R.drawable.hori_top);
        } else if (c[1][0] == 1 && c[1][1] == 1 && c[1][2] == 1 || c[1][0] == 2 && c[1][1] == 2 && c[1][2] == 2) {
            strike.setImageResource(R.drawable.hori_center);
        } else if (c[2][0] == 1 && c[2][1] == 1 && c[2][2] == 1 || c[2][0] == 2 && c[2][1] == 2 && c[2][2] == 2) {
            strike.setImageResource(R.drawable.hori_bottom);
        } else if (c[0][0] == 1 && c[1][0] == 1 && c[2][0] == 1 || c[0][0] == 2 && c[1][0] == 2 && c[2][0] == 2) {
            strike.setImageResource(R.drawable.verti_left);
        } else if (c[0][1] == 1 && c[1][1] == 1 && c[2][1] == 1 || c[0][1] == 2 && c[1][1] == 2 && c[2][1] == 2) {
            strike.setImageResource(R.drawable.verti_center);
        } else if (c[0][2] == 1 && c[1][2] == 1 && c[2][2] == 1 || c[0][2] == 2 && c[1][2] == 2 && c[2][2] == 2) {
            strike.setImageResource(R.drawable.verti_right);
        } else if (c[0][0] == 1 && c[1][1] == 1 && c[2][2] == 1 || c[0][0] == 2 && c[1][1] == 2 && c[2][2] == 2) {
            strike.setImageResource(R.drawable.diagonal_l);
        } else if (c[0][2] == 1 && c[1][1] == 1 && c[2][0] == 1 || c[0][2] == 2 && c[1][1] == 2 && c[2][0] == 2) {
            strike.setImageResource(R.drawable.diagonal_r);
        } else {
            Toast.makeText(getApplicationContext(), "ELSE", Toast.LENGTH_SHORT).show();
        }
    }

    //used to save score using SHARED PREFERENCES method after every win/draw
    //Parameter : data = Player 1/Player 2/Draw , scor = SCORES
    private void savePoints(String data, int scor) {
        switch (data) {
            case "p1":
                se.putInt("p1", scor);
                break;
            case "p2":
                se.putInt("p2", scor);
                break;
            case "dr":
                se.putInt("dr", scor);
        }
        se.commit();
    }

    //used to display custom toast when user wins/draws the match
    //Parameter : player = PLAYER 1 or PLAYER 2 ( to show who won) else DRAW
    private void custom_toast(String player) {
        LayoutInflater ll = getLayoutInflater();
        View vv = ll.inflate(R.layout.my_custom_toast_layout, (ViewGroup) findViewById(R.id.toast_layout));
        TextView tt, st;
        ImageView lef, rig;
        lef = (ImageView) vv.findViewById(R.id.imageView);
        rig = (ImageView) vv.findViewById(R.id.imageView1);
        lef.setImageResource(R.drawable.leg);
        rig.setImageResource(R.drawable.mountain);
        tt = (TextView) vv.findViewById(R.id.title);
        st = (TextView) vv.findViewById(R.id.subtitle);
        tt.setText("Draw");
        st.setText("One Step Closer to Win");
        if (player != "draw") {
            tt.setText(player + " WIN");
            lef.setImageResource(R.drawable.cup);
            rig.setImageResource(R.drawable.medal);
            if (player == "Player 1")
                st.setText("Player 2 Lost");
            else
                st.setText("Player 1 Lost");
        }
        Toast t = new Toast(getApplicationContext());
        t.setDuration(Toast.LENGTH_SHORT);
        t.setGravity(Gravity.BOTTOM, 0, 0);
        t.setView(vv);
        t.show();
    }


    //Used to display Context MENU by adding menu item and its indexes
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0, v.getId(), 0, "New Game");
        menu.add(0, v.getId(), 1, "Stats");
        menu.add(0, v.getId(), 2, "Reset Stats");
        menu.add(0, v.getId(), 3, "Creators");
    }

    //Used to perform operation when user selects any menu item
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if (item.getTitle() == "Stats") {
            //Toast.makeText(getApplicationContext(), "<STATS>", Toast.LENGTH_LONG).show();
            sp = getSharedPreferences("my_scores", Context.MODE_PRIVATE);
            int p1, p2, dr;
            p1 = sp.getInt("p1", 0);
            p2 = sp.getInt("p2", 0);
            dr = sp.getInt("dr", 0);
            String info = "Total Games : " + (p1 + p2 + dr) + "\n" +
                    "--------------------------" + "\n" +
                    "Player 1 Wins : " + p1 + "\n" +
                    "Player 1 Loss : " + p2 + "\n" +
                    "--------------------------" + "\n" +
                    "Player 2 Wins : " + p2 + "\n" +
                    "Player 2 Loss : " + p1 + "\n" +
                    "--------------------------";
            Toast.makeText(getApplicationContext(), info, Toast.LENGTH_LONG).show();
        } else if (item.getTitle() == "New Game") {
            ng.callOnClick();
        } else if (item.getTitle() == "Creators") {
            Toast.makeText(getApplicationContext(), "Aparupa Basu Roy - 2015HW68117 \n Anshita Singh - 2015HW6101 \n" +
                    " Irfana Banu B - 2015HW68288 \n Pooja Suresh Raut - 2015HW68521 \n" +
                    " Komal Sinha - 2015HW69884", Toast.LENGTH_LONG).show();
        } else if (item.getTitle() == "Reset Stats") {
            se.putInt("pl", 0);
            se.putInt("p2", 0);
            se.putInt("dr", 0);
            se.clear();
            se.commit();
            Toast.makeText(getApplicationContext(), "Stats Cleared", Toast.LENGTH_SHORT).show();
        } else
            return false;
        return true;
    }
    //END COntext MENU
}




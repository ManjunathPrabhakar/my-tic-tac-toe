package com.sdpd_d_batch3.wase15.my_tictactoe;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

public class StartActivityFull extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_start_full);

        TextView tv = (TextView)findViewById(R.id.header);
        Typeface typeFace_t = Typeface.createFromAsset(getAssets(), "planet_benson.ttf");
        tv.setTypeface(typeFace_t);

        Handler h = new Handler();
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(StartActivityFull.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        },3000);





    }
}
